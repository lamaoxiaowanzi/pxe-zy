chrt -d --sched-runtime 10000000 --sched-deadline 10000000 --sched-period 10000000 0 $*
